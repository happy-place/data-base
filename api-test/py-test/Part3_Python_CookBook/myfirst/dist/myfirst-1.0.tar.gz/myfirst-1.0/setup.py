#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Author: HuHao <huhao1@cmcm.com>
Date: '2018/8/6'
Info:
        
"""

from distutils.core import setup

setup(name='myfirst',
      version='1.0',
      author='Tom kitty',
      author_email='tom@kitty.com',
      url='http://www.you.com/projectname',
      packages=['myfirst', 'myfirst.utils'],
      )

